package crudsha256.crud.completo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudCompletoApplicationTests {

	@Test
	void contextLoads() {
	}

}
